<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>JML Pre-Registration</title>
        <meta name="author" content="Anthony Okagba">
        <link rel="shortcut icon" href="img/logo.png" type="image/x-icon">

        <link rel="shortcut icon" href="https://jmlfoods.com/img/logo.png" type="image/x-icon" />
        <link rel="apple-touch-icon" href="https://jmlfoods.com/img/logo.png" />
        <link rel="apple-touch-icon" sizes="57x57" href="https://jmlfoods.com/img/logo.png" />
        <link rel="apple-touch-icon" sizes="72x72" href="https://jmlfoods.com/img/logo.png" />
        <link rel="apple-touch-icon" sizes="76x76" href="https://jmlfoods.com/img/logo.png" />
        <link rel="apple-touch-icon" sizes="114x114" href="https://jmlfoods.com/img/logo.png" />
        <link rel="apple-touch-icon" sizes="120x120" href="https://jmlfoods.com/img/logo.png" />
        <link rel="apple-touch-icon" sizes="144x144" href="https://jmlfoods.com/img/logo.png" />
        <link rel="apple-touch-icon" sizes="152x152" href="https://jmlfoods.com/img/logo.png" />
        <link rel="icon" type="icon" href="https://jmlfoods.com/img/logo.png"/>

        <link rel="stylesheet" href="css/bootstrap-grid.min.css">
        <link rel="stylesheet" href="css/bootstrap-reboot.min.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/css/fontawesome.css">
        <link rel="stylesheet" href="css/css/all.min.css">
        <link rel="stylesheet" href="css/css/brands.min.css">
        <link rel="stylesheet" href="css/css/regular.min.css">
        <link rel="stylesheet" href="css/css/solid.min.css">
        <link rel="stylesheet" href="css/webfonts/fa-brands-400.svg">
        <link rel="stylesheet" href="css/webfonts/fa-regular-400.svg">
        <link rel="stylesheet" href="css/webfonts/fa-solid-900.svg">

        <!-- <link rel="stylesheet" href="prestyle.css"> -->

        <style>
            html {
                scroll-behavior: smooth;
                transition: 1s;
            }

            body {
                position: relative;
                margin: 0;
                padding: 0;
                line-height: 2.85em;
                font-size: 15px;
                font-weight: 500;
                font-family: 'Poppins', sans-serif;
                color: #000000;
            }

            .navbar {
                padding-left: 50px;
                padding-right: 50px;
            }

            .bg-light {
                background-color: red!important;
            }

            .center {
                text-align: center;
                align-content: center;
            }

            .font-big{
                font-family: 'Poppins', sans-serif;
                line-height: 1.3em;
                color: #ffffff;
                display: block;
                padding-top: 50px;
                font-weight: 800;
                font-size: 40px;
                margin-bottom: 10px;
            }

            @media (max-width:501px) {
                .font-big{
                    font-family: 'Poppins', sans-serif;
                    line-height: 1.3em;
                    color: #ffffff;
                    display: block;
                    padding-top: 50px;
                    font-weight: 500;
                    font-size: 30px;
                    margin-bottom: 10px;
                }
            }
            @media (max-width:350px) {
                .font-big{
                    font-family: 'Poppins', sans-serif;
                    line-height: 1.3em;
                    color: #ffffff;
                    display: block;
                    padding-top: 50px;
                    font-weight: 500;
                    font-size: 30px;
                    margin-bottom: 10px;
                }
            }

            .img-banner{
                background-image: url('../img/banner1.jpg');
                height: 550px;
                width: 100%;
                display: block;
                background-attachment: fixed;
                background-repeat: no-repeat;
                background-position: 50% 60%;
                background-size: cover;
                -moz-background-size: cover;
            }

            .imgv {
                background: rgba(0, 0, 0, 0.493);
                height: 100%;
                width: 100%;
            }

            .form-area .input-area, .form-area .select-area, .form-area .text-area {
                position: relative;
            }

            .form-area .input-area input, .form-area .select-area select, .form-area .text-area textarea {
                width: 100%;
                display: block;
                margin-bottom: 20px;
                border-bottom: 1px solid #dadada;
                padding: 10px;
                padding-left: 0;
                font-size: 14px;
                border-left: 0;
                border-right: 0;
                border-top: 0;
                -webkit-transition: all 0.2s ease-in-out;
                -moz-transition: all 0.2s ease-in-out;
                -o-transition: all 0.2s ease-in-out;
                transition: all 0.2s ease-in-out;
                outline: none;
            }

            .form-area .floating-label {
                position: absolute;
                pointer-events: none;
                left: 0;
                top: 10px;
                transition: 0.2s ease all;
                font-size: 14px;
            }

            .form-area input:focus ~ .floating-label, .form-area input:not(:focus):valid ~ .floating-label, .form-area textarea:focus ~ .floating-label, .form-area textarea:not(:focus):valid ~ .floating-label {
                top: -12px;
                left: 0;
                font-size: 11px;
                opacity: 1;
                color: #3e43e9;
            }

            .footer {
                background-color: black;
                padding-top: 10px;
                padding-bottom: 10px;
            }
            .copyright h5 {
                font-size: 12px;
                text-align: center;
                color: white;
            }

            .social-linksk {
                height: auto;
                overflow: hidden;
                text-align: center;
            }

            .social-linksk a i{
                display: inline-block;
                width: 34px;
                line-height: inherit;
                font-size: 14px;
                position: relative;
                color: rgb(255, 255, 255) !important;
                -webkit-transition: all 200ms ease-out;
                transition: all 200ms ease-out;
            }
        </style>
    </head>
    <body>
        <nav id="navbar" class="navbar navbar-light bg-danger fixed-top shadow nav">
            <a class="navbar-brand" href=""><img class="logo" src="img/logo.png" alt="logo" style="width: 50px;"></a>
            <div id="my-navb" class="collapse,">
                <ul class="navbar-nav ml-auto">
                    <button class="btn btn-primary" href="#" data-toggle="modal" data-target="#regModal">
                        Register
                    </button>
                </ul>
            </div>
        </nav>
        <div class="img-banner" style="padding-top: 90px;">
            <div class="imgv">
                <div class="welcome font-big center" style="padding-top: 190px;">
                    <h3 class="font-big">Welcome to JML Foods Investment Company Nigeria</h3>
                </div>
            </div>
        </div>
        <div class="container-fluid center" style="padding-top: px;">
                <div class="row text-justify">
                    <div class="col-md-6 font-sm">
                        <p>JML Foods Investment Company is Africa's most innovative food production 
                            saving services with various options to help you quench your hunger. 
                            We have created a strategy that could help our partners to make extra 
                            income on monthly and weekly bases. And to also make you acquire your 
                            long dream asset at the click of a button.
    
                            <br>We are Using technology as our primary leverage, we are gradually 
                            becoming the largest online cum offline food and wealth provider for 
                            the people.
                            We believe it can only be fully achieved via the provision of food which 
                            is obviously a basic human right as enshrined in the United Nations (UN) 
                            human rights charter.
                        </p>
                    </div>
                    <div class="col-md-6 font-sm">
                        <p> Since inception, we have been able to use our local food production 
                            such as Poundo Yam, Semovita, and Wheat to improve the economic standing 
                            of all our customers at every level providing powerful opportunities and 
                            insight. As a confirmation that the right chord had been struck, the 
                            concept is quickly attracting huge number of participants from all 
                            walks of life-civil servants, traders, artisans, pensioners, farmers, 
                            students and other low income earners-whose fortunes have now taken an 
                            upward swing.
                            
                        </p>
                    </div>
                </div>
                <button class="btn btn-dark" href="#" data-toggle="modal" data-target="#readmoreModal">
                    Read More
                </button>
                <button class="btn btn-primary" href="#" data-toggle="modal" data-target="#regModal">
                    Register
                </button>
            </div>
        </div>





        <div class="modal fade" id="regModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog center" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title center" id="exampleModalLabel">Pre Register</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="container-fluid">
                        <form action="" method="POST" enctype="multipart/form-data" id="validation" class="form-area">
                            <div class="row pt-3">
                                <div class="col-md-12">
                                    <div class="input-area">
                                        <input name="fname" type="text" required="required">
                                        <label class="floating-label">Name*</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="input-area">
                                        <input name="tel" type="tel" required="">
                                        <label class="floating-label">Phone Number*</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="input-area">
                                        <input name="wnum" type="tel" required="">
                                        <label class="floating-label">WhatsApp Number*</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="input-area">
                                        <input name="email" type="email" required="">
                                        <label class="floating-label">Email*</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="input-area">
                                        <input name="state" type="text" required="">
                                        <label class="floating-label">State*</label>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer center">
                                <div class="col-12 center">
                                    <button name="reg_btn" type="submit" class="btn btn-primary">Pre Register</button>
                                </div>
                            </div>
                        </form>
                </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="readmoreModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Pre Registration</h5>
                  <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="container-fluid text-justify">
                    <p style="font-size: 14px;">
                        <small>SPECIAL INFORMATION:</small><br>

                        Thank you for the opportunity to meet you here.<br>
                        I have a secret to share with you.<br>

                        Are you a team leader? Network leader or you are aspiring 
                        to become one, but you haven't gotten any platform to establish 
                        your leadership quality?<br>

                        JML Foods  Investment is here to give you the opportunity to show your leadership 
                        skills as we are only recruiting pioneers..<br>

                        We are looking for Top Pioneering Team members in in Nigeria  of a brand new company 
                        which will be launching soon... You can be part of the team leaders if you have the 
                        quality and you have  the ability to become one..<br>

                        Only pioneering team leaders/State representative  are being recruited now and this is a 
                        deep secret I'm revealing to you. <br>

                        We have only 20 Leadership slot to recommend. Wouldn't you rather be among them?
                        The company is a registered company under CAC..<br>

                        JML Foods is a manufacturer of foods flour such as Poundo Yam, Wheat, Semo, Custard, 
                        Beans flour,  etc... We have field marketers around Lagos.<br>

                        We have decided to create a strong MLM cum investment platform for people who will like 
                        to make extra income.<br>

                        Our product are very cheep and affordable for everyone.<br>
                        Good product, confirmed efficacy, quality and quantity enough that match the value of your clients.<br>
                        Simply put, cheep and affordable comparing to the likes in the market today.<br>

                        Our matrix is 2 by 2 from feeder stage to the final stage. Which makes it possible for our 
                        partners to move swiftly to the final stage withing a short  months.<br>

                        All we want from you is your indication to accept to be part of the pioneering team leaders/state 
                        rep and fulfill the requirements and also get ready to take your slot when the portal for Registration 
                        opens immediately after the lockdown.<br>

                        <strong>REQUIREMENTS:</strong> <br>
                        1. Integrity and Focused<br>
                        2. Sincerity and  Commitment<br>
                        3. Truthful and Loyal<br>
                        4. Ability to mobilize prospect <br>
                        5. Never accept defeat.<br>


                        If you know you have these qualities, indicate NOW so I add you to the Leaders WhatsApp Group 
                        chat for more training, information and orientation.<br>
                        This is a different brand new system with the Networker at heart while maintaining the food product 
                        in its high standard.<br>
                        As a matter of fact,<br>

                        Your prospect as two mind blowing options to choose from.<br>

                        1. Networking. <br>
                        2. Investment. <br>


                        The compensation plan is quite irresistible for networkers..<br>



                        While waiting for your quick response, your decision is the ultimate.<br>

                        Respond  fast, remember we are recruiting ONLY 20 GREAT leaders NOW !! 

                    </p>
                <div class="modal-footer">
                    <div class="col-12 center">
                        <button type="button" data-dismiss="modal" class="btn btn-secondary " >Cancel</button>
                    </div>
                </div>
              </div>
            </div>
            </div>
        </div>
        
        <footer class="pt-3">
            <div class="footer pt-3">
                <div class="copyright">
                    <!-- <img class= "logo" src="img/logo.png" alt="" style="width: 50px;"><br/> -->
                    <div class="col-sm-12 pt-2 pb-2">
                        <div class="social-linksk">
                        <a href="https://facebook.com/JMLfoods" title="facebook" target="_blank"><i class="fab fa-facebook"> </i></a>
                        <a href="https://twitter.com/JMLfoods" title="twitter" target="_blank"><i class="fab fa-twitter"> </i></a>
                        <!-- <a href="https://linkedin.com/in/JMLfoods" title="linkedin" target="_blank"><i class="fa fa-linkedin"> </i></a> -->
                        <a href="https://instagram.com/JMLfoods" title="instagram" target="_blank"><i class="fab fa-instagram"> </i></a>
                        </div>
                    </div>

                    <h5>Copyright &copy; 2020 JML FOODS INVESTMENT COMPANY Nigeria Ltd. | All Rights Reserved.</h5>
                </div>
            </div>
        </footer>

        <?php
            if(isset($_POST['reg_btn']))
            {
            
                $fname = $_POST['fname'];
                $email = $_POST['email'];
                $state = $_POST['state'];
                $tel = $_POST['tel'];
                $wnum = $_POST['wnum'];

                $to = 'contactjmlfoods01@gmail.com';
                $subject = 'JML FOODS PRE REGISTERATION';
                $message = "
                Contact Details: \r\n
                Name: ".$fname."\r\n
                Phone Number: ".$tel."\r\n
                WhatsApp Number: ".$wnum."\r\n
                Email: ".$email."\r\n
                State: ".$state."  \r\n";
                $header = "From: <".$email."> \r\n";
                "Reply-To: ".$email." \r\n"; 
                // $retval = mail ($to,$subject,$message,$header);
                if(mail($to,$subject,$message,$header)) {
                    echo "
                    <script>
                        alert('".$fname." you have successfully registered to JML Foods');
                        //  window.location='last-page.html';
                    </script>
                    ";
                }
                else{
                        echo "
                        <script>
                                alert('Not Sent');
                                //  window.location='index.html';
                            </script>
                            ";
                    }
                }
            // }
         
        ?>
        <script src="js/jquery-3.4.1.min.js"></script>
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </body>
</html>