<?php
session_start();
date_default_timezone_set("Africa/Lagos"); 

include ('includes/dbconnect.php');

if (!$_SESSION['user_name'])
{
    header("location:login.php");
}

?>