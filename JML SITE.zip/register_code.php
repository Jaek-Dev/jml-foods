<?php
// session_start();
include ('security.php');

include ('includes/dbconnect.php');

if(isset($_POST['register-btn']))
{

    $name = $_POST['name'];
    $username = $_POST['username'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cpassword = $_POST['confirmpassword'];
    $state = $_POST['state'];
    $bank_name = $_POST['bank_name'];
    $acc_name = $_POST['acc_name'];
    $acc_no = $_POST['acc_no'];
    $sponser_name = $_GET['sponser_name'];
    $joined_date = $_POST['joined_date'];

    $email_query = "SELECT * FROM users WHERE email='$email'";
    $email_query_run = mysqli_query($con, $email_query);
    if(mysqli_num_rows($email_query_run) > 0)
    {
        $_SESSION['status'] = "Email already Taken";
        header('location: register');
    }
    else
    {
        if ($password === $cpassword)
        {

            $sponser_query = "SELECT * FROM users WHERE username='$sponser_name'";
            $sponser_query_run = mysqli_query($con, $sponser_query);
            if(!mysqli_fetch_array($sponser_query_run))
            {
                $_SESSION['status'] = "Sponser Name is Invalid";
                header('location: register');
            }
            else
            {
                $query = "INSERT INTO users (name,username,phone,email,password,state,bank_name,acc_name,acc_no,sponser_name,joined_date) 
                VALUE ('$name','$username','$phone','$email','$password','$state','$bank_name','$acc_name','$acc_no','$sponser_name','$joined_date')";
                $query_run = mysqli_query($con,$query);
            
                if($query_run)
                {

                    $spquery = "INSERT INTO sponser (sponser_name,downline_name) 
                    VALUE ('$sponser_name', '$username')";
                    $spquery_run = mysqli_query($con,$spquery);

                    if($spquery_run)
                    {
                        $succs .= '<div class="success">Your Account Have Been Created Please Login to continue!</div>';
                        $subject = 'Welcome To JML FOODS your Registration was Sucessful';
                        $to = $email;
                        $message = "Welcome To JML FOOD your Registration was Sucessful \r\n
                        Your Details Below:\r\n
                        Email: ".$email."\r\n
                        Username: ".$username."\r\n
                        PassWord: ".substr($password,0,3)."******   \r\n
                        To Login Click Below Link or Copy To your Browser:\r\n
                        www.jmlfoods.com/login \r\n
                        Contact Details: \r\n
                        Mobile: +2348023396375\r\n
                        Email: contactjmlfoods01@gmail.com\r\n
                        Brought By: JML FOODS INVESTMENT COMPANY LTD \r\n
                        ".date('Y')." - JML Foods \r\n
                        JML FOODS INVESTMENT COMPANY \r\n";
                        $header ="From: <contactjmlfoods01@gmail.com>\r\n";
                        "Reply-To: contactjmlfoods01@gmail.com\r\n"; 
                        
                        if(mail($to,$subject,$message,$header)){

                            $_SESSION['success'] = "Profile Created";
                            // echo "Welcome '$name','$username','$phone','$email','$password','$state','$bank_name','$acc_name','$acc_no','$sponser_name','$joined_date'";
                            $_SESSION['user_name'] = $username;
                            header('location: member/index');    
                        }
                        else 
                        {
                            $_SESSION['status'] = "Mail Not Sent";
                            header('location: register');
                        }
                    }
                    else 
                    {
                        $_SESSION['status'] = "Sponser Name Not Created";
                        header('location: register');
                    }
                }
                else 
                {
                    $_SESSION['status'] = "Profile Not Created";
                    header('location: register');
                }
                // } 
            }
        }
        else
        {
            $_SESSION['status'] = "Password and Confirm Password Does Not Match";
            header('location: register');
        }
    }
}

?>