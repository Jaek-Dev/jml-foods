<?php
session_start();
// include ('security.php');
date_default_timezone_set("Africa/Lagos");

?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Register - JML FOODS INVESTMENT COMPANY</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta data-react-helmet="true" name="description" content="JML FOODS INVESTMENT COMPANY is Africa's most innovative food production saving services with various options to help you quench your hunger.">
        <meta data-react-helmet="true" name="keywords" content="JML, Food, JML Foods, food production, INVESTMENT COMPANY, Help you quench your hunger">
        <meta data-react-helmet="true" property="og:title" content="JML FOODS | INVESTMENT COMPANY">
        <meta data-react-helmet="true" property="og:description" content="JML FOODS INVESTMENT COMPANY is Africa's most innovative food production saving services with various options to help you quench your hunger.">
        <meta data-react-helmet="true" property="og:type" content="website">
        <meta data-react-helmet="true" property="og:url" content="https://jmlfoods.com/">
        <meta data-react-helmet="true" property="og:site_name" content="JML FOODS | INVESTMENT COMPANY">
        <meta name="author" content="Anthony Okagba">
        <link rel="shortcut icon" href="/img/logo.png" type="image/x-icon">

        <link rel="stylesheet" href="/css/bootstrap-grid.min.css">
        <link rel="stylesheet" href="/css/bootstrap-reboot.min.css">
        <link rel="stylesheet" href="/css/bootstrap.min.css">
        <link rel="stylesheet" href="/css/font-awesome.min.css">
        <link rel="stylesheet" href="/css/style.css">
        <link href="http://fonts.googleapis.com/css?family=Raleway:200,400,300,600,500,700" rel="stylesheet" type="text/css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        
    </head>
    <body>

        <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top shadow">
            <a class="navbar-brand" href="index"><img class="logo" src="/img/logo.png" alt="logo" style="width: 70px;"></a>
            <button class="navbar-toggler" data-target="#my-nav" data-toggle="collapse" aria-controls="my-nav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div id="my-nav" class="collapse navbar-collapse">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="/">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#about">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#work">How it Works</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#gallery">Gallery</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#contact"> Contact Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#compensation">Compensation Plan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/account/login"> Login</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="/account/register">Register</a>
                    </li>
                </ul>
            </div>
        </nav>

        <div class="img-banner" style="padding-top:70px">
            <div class="img">
                <h1>Create an Account</h1>
            </div>
        </div>

        <div id="contact">
                  
            <div class="" style="padding-top: 100px;">
                <div class="contact parallax_img" style="background-position: 0px 373.36px;">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-8 col-sm-12 m-auto">
                                <div class="contact-form">
                                    <div class="section-heading text-center">
                                        <h2 class="section-title bg">Create an Account</h2>
                                        <?php
    if(isset($_SESSION['success']) && $_SESSION['success'] !='')
    {
        echo '<div class="alert alert-info">'.$_SESSION['success'].' <a class="close" data-dismiss="alert">×</a> </div>';
        unset($_SESSION['success']);
    }
    
    if(isset($_SESSION['status']) && $_SESSION['status'] !='')
    {
        echo '<div class="alert alert-danger">'.$_SESSION['status'].' <a class="close" data-dismiss="alert">×</a> </div>';
        unset($_SESSION['status']);
    }
    ?>
                                    </div>
                                    <form method="POST" id="validation" class="form-area"> 
                                        <div class="row">
                                            <!-- <div class="col-md-12">
                                                <div class="input-area">
                                                    <input name="sponser_id" type="text" required="required">
                                                    <label class="floating-label">Sponser ID*</label>
                                                </div>
                                            </div> -->
                                            <div class="col-md-6">
                                                <div class="input-area">
                                                    <input name="name" type="text" required="required">
                                                    <label class="floating-label">Full Name*</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="input-area">
                                                    <input name="username" type="text" required="">
                                                    <label class="floating-label">Username*</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="input-area">
                                                    <input name="phone" type="tel" required="">
                                                    <label class="floating-label">Phone Number*</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="input-area">
                                                    <input name="email" type="email" required="">
                                                    <label class="floating-label">Email Address*</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="input-area">
                                                    <input name="password" type="password" required="">
                                                    <label class="floating-label">Password*</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="input-area">
                                                    <input name="confirmpassword" type="password" required="">
                                                    <label class="floating-label">Confirm Password*</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="input-area">
                                                    <input name="state" type="text" required="">
                                                    <label class="floating-label">State*</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="input-area">
                                                    <input name="bank_name" type="text" required="">
                                                    <label class="floating-label">Bank Name*</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="input-area">
                                                    <input name="acc_name" type="text" required="">
                                                    <label class="floating-label">Account Name*</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="input-area">
                                                    <input name="acc_no" type="number" required="">
                                                    <label class="floating-label">Account Number*</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="input-area">
                                                    <input name="sponser_name" type="text" required="">
                                                    <label class="floating-label">Sponsor ID*</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="input-area">
                                                    <!-- <label class="floating-label1">Joined Date</label> -->
                                                    <input name="joined_date" type="text" value="<?php echo date("F j, Y, g:i a"); ?>" hidden>
                                                </div>
                                            </div>
                                            <div class="col-12 text-center">
                                                <button name="register-btn" type="submit" class="btn btn btn-danger">Register</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php
include ('includes/scripts.php');
include ('includes/footer.php');
?>