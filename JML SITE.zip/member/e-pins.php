<?php
/*************************************************************
*    Project Name        JML Food Investment                 *
*    Project URI         https://www.jmlfoods.com            *
*    Project Author      Jay                                 *
*    Author URI          https://m.me/ComputerGuru1          *
*    Author Digit        +234(0)-813-508-7475                *
*    Copyright           GNU V2.2                            *
*    Version             1.0.1                               *
**************************************************************

**************************************************************
*   The Registration Pins	                                 *
*************************************************************/

include ('security.php');

// include ('includes/dbconnect.php');
include ('includes/header.php');
include ('includes/navbar.php');
require_once( "classes/database.php" );
require_once( "classes/users.php" );

?>

<div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Registration Pins</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="index">Home</a></li>
              <li class="breadcrumb-item active">Registration Pins</li>
            </ol>
          </div>
        </div>

<hr>

<div class="card">
    <div class="card-body">
        <?php
        $DB = new DB;
        if( !empty( $_GET[ "generate" ] ) && $_GET[ "generate" ] == "true" ) {
            //Generate registration pins, only when active pins are less than 20. LIMIT is 50
            $sql = "SELECT * FROM reg_pins WHERE status = 0";
            if( $DB->numRows( $sql ) < 20 ) {
                $active_pins = $DB->numRows( $sql );
                $max = 50 - $active_pins;
                $inserted = [];
                for( $i = 0; $i < $max; $i++ ) {
                    $random = random_int( 1111111111111111, 9999999999999999 );
                    //Check if random number already exist
                    $sql = "SELECT * FROM reg_pins WHERE pin = $random";
                    if( $DB->numRows( $sql ) > 0 ) {
                        //Pin already exist. Continue generating
                        continue;
                    } else {
                        //Pin doesn't exist, Insert to database
                        $sql = "INSERT INTO reg_pins( pin ) VALUES( '$random' )";
                        if( $DB->insert( $sql ) ) {
                            //Pin inserted
                            array_push( $inserted, $random );
                        }
                    }
                }

                if( !empty( $inserted ) ) {
                    echo "<div class='alert alert-success'>";
                    echo count( $inserted ) . " registration pin(s) has been successfully generated.";
                    echo "</div>";
                }
            } else {
                echo "<div class='alert alert-danger'>";
                echo "You can only generate registration pins when the available ones are less than 20.";
                echo "</div>";
            }
            
            
        }
        ?>
        <table class="table table bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>PIN Number</th>
                    <th>Status</th>
                    <th>Generated On</th>
                    <th>Used On</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM reg_pins ORDER BY status ASC LIMIT 50";
                if( $DB->numRows( $sql ) < 1 ) {
                    echo "<tr>";
                    echo "<td colspan='6'>";
                    echo "<div class='alert alert-info'>";
                    echo "It looks like you have not generated any registration pin or all pins have been used. Please <a href='?generate=true'>generate new pins</a> now.";
                    echo "</div>";
                    echo "</td>";
                    echo "</tr>";
                } else {
                    //Pins are available... Display them
                    $pins = $DB->select( $sql );
                    foreach( $pins as $key => $value ) {
                        $id = $value[ "id" ];
                        $pin = $value[ "pin" ];
                        $date_gen = date( "F j Y, h:i:s a", strtotime( $value[ "date" ] ) );
                        $date_used = $value[ "date_used" ];
                        $status = $value[ "status" ];
                        switch( $status ) {
                            case 0: 
                                $active = "<font color='green'>Available</font>";
                            break;

                            case 1:
                                $active = "<font color='red'>Unavailable</font>";
                            break;

                            default: 
                                $active = "<font color='orange'>Unknown</font>";
                            break;
                        }

                        echo "<tr>";
                        echo "<td>$id</td>";
                        echo "<td>$pin</td>";
                        echo "<td>$active</td>";
                        echo "<td>$date_gen</td>";
                        echo "<td>" . ( !empty( $date_used ) ? date( "F j Y, h:i:s a", strtotime( $value[ "date_used" ] ) ) : "Not Used" ) . "</td>";
                        echo "<td><a href='?action=delete&id=$id'><small><i class='far fa-trash-alt'></i> Delete Pin</small></a></td>";
                        echo "</tr>";
                    }

                    

                }

                ?>
            </tbody>
        </table>
    </div>
</div>

&hercon;




<hr>

<?php
include ('includes/scripts.php');
include ('includes/footer.php');
?>