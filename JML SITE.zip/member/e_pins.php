<?php
include ('security.php');

// include ('includes/dbconnect.php');
include ('includes/header.php');
include ('includes/navbar.php');
?>

<div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Withdraw</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="index">Home</a></li>
              <li class="breadcrumb-item active">Withdraw</li>
            </ol>
          </div>
        </div>

<hr>

<div class="card">
     <div class="container">
        <div class="ro">
            uuu
        </div>
    </div>
</div>






<hr>

<?php
include ('includes/scripts.php');
include ('includes/footer.php');
?>