<?php
// session_start();
include ('security.php');
date_default_timezone_set("Africa/Lagos"); 
// echo date("F j, Y, g:i a");
include ('includes/dbconnect.php');
include ('includes/header.php');
include ('includes/navbar.php');
$username = $_SESSION[ "user" ][ "username" ];
?>

        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Dashboard</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
            </ol>
          </div>
        </div>
      </div>
    </div>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Info boxes -->
        <div class="row">
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box">
              <span class="info-box-icon bg-info elevation-1"><i class="fas fas fa-user"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Your Username</span>
                <span class="info-box-number">
                  <?php echo $username; ?>
                </span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box mb-3">
              <span class="info-box-icon bg-danger elevation-1"><i class="fas fa-user"></i></span>
<?php
  $query = "SELECT id FROM users WHERE username='$username'";
  $query_run = mysqli_query($con, $query);
  $row = mysqli_fetch_array($query_run);
  {

?>
              <div class="info-box-content">
                <span class="info-box-text">User ID</span>
                <span class="info-box-number">
                  <?php echo $row['id']; ?>
                </span>
              </div>
            </div>
          </div>
<?php
  }
?>

          <!-- fix for small devices only -->
          <div class="clearfix hidden-md-up"></div>

          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box mb-3">
              <span class="info-box-icon bg-success elevation-1"><i class="far fa-user"></i></span>

              <?php
  $query = "SELECT sponser_name FROM sponser WHERE downline_name='$username'";
  $query_run = mysqli_query($con, $query);
  $row=mysqli_fetch_array($query_run);
?>


              <div class="info-box-content">
                <span class="info-box-text">Sponser Name</span>
                <span class="info-box-number"><?php echo $row['sponser_name']; ?></span>
              </div>
            </div>
          </div>
          
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box mb-3">
              <span class="info-box-icon bg-warning elevation-1"><i class="fas fa-users"></i></span>

<?php
  $sql="select count(sponser_name) as total from sponser WHERE sponser_name = '$username'";
  $result=mysqli_query($con,$sql);
  if($result)
 {
    while($row=mysqli_fetch_assoc($result))
  {
    ?>
              <div class="info-box-content">
                <span class="info-box-text">Total Refferal</span>
                <span class="info-box-number"><?php echo $row ['total']; ?></span>
              </div>
            </div>
          </div>
        </div>
        <?php
      }     
    }
   ?>

      </div>
    </section>
  </div>


<?php
include ('includes/scripts.php');
include ('includes/footer.php');
?>