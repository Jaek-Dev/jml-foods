<?php
/*************************************************************
*    Project Name        JML Food Investment                 *
*    Project URI         https://www.jmlfoods.com            *
*    Project Author      Jay                                 *
*    Author URI          https://m.me/ComputerGuru1          *
*    Author Digit        +234(0)-813-508-7475                *
*    Copyright           GNU V2.2                            *
*    Version             1.0.1                               *
**************************************************************

**************************************************************
*   The User Login      	                                 *
*************************************************************/
// session_status();

include ('security.php');
require_once( "classes/database.php" );
require_once( "classes/users.php" );
$DB = new DB;

if(isset($_POST['logout_btn'])) {
    //Register user's last login date
    $sql = "UPDATE users SET last_login = NOW()";
    if( $DB->query( $sql ) ) {
        //Last seen updated
        //Destroy the user session
        session_unset( $_SESSION[ "user" ] );
        session_destroy();
        header( "Location: /account/login" );
    } else {
        echo $DB->error();
    }
}


?>