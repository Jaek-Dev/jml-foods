<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="description" content="">
        <meta data-react-helmet="true" name="description" content="JML Foods Investment Company is Africa's most innovative food production saving services with various options to help you quench your hunger.">
        <meta data-react-helmet="true" name="keywords" content="JML, Food, JML Food, food production, INVESTMENT COMPANY, Help you quench your hunger">
        <meta data-react-helmet="true" property="og:title" content="JML FOODS | INVESTMENT COMPANY">
        <meta data-react-helmet="true" property="og:description" content="JML FOODS Investment Company is Africa's most innovative food production saving services with various options to help you quench your hunger.">
        <meta data-react-helmet="true" property="og:type" content="website">
        <meta data-react-helmet="true" property="og:url" content="https://jmlfoods.com/">
        <meta data-react-helmet="true" property="og:site_name" content="JML FOODS | INVESTMENT COMPANY">
        <meta data-react-helmet="true" property="og:site_logo" content="https://jmlfoods.com/img/logo.png">
        <meta name="author" content="Anthony Okagba">
        <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon">

        <link rel="shortcut icon" href="https://jmlfoods.com/img/logo.png" type="image/x-icon" />
        <link rel="apple-touch-icon" href="https://jmlfoods.com/img/logo.png" />
        <link rel="apple-touch-icon" sizes="57x57" href="https://jmlfoods.com/img/logo.png" />
        <link rel="apple-touch-icon" sizes="72x72" href="https://jmlfoods.com/img/logo.png" />
        <link rel="apple-touch-icon" sizes="76x76" href="https://jmlfoods.com/img/logo.png" />
        <link rel="apple-touch-icon" sizes="114x114" href="https://jmlfoods.com/img/logo.png" />
        <link rel="apple-touch-icon" sizes="120x120" href="https://jmlfoods.com/img/logo.png" />
        <link rel="apple-touch-icon" sizes="144x144" href="https://jmlfoods.com/img/logo.png" />
        <link rel="apple-touch-icon" sizes="152x152" href="https://jmlfoods.com/img/logo.png" />
        <link rel="icon" type="icon" href="https://jmlfoods.com/img/logo.png"/>

  <title><?= !empty( $page_title ) ? $page_title : "Dashboard" ?> - JML Foods</title>

  <link rel="stylesheet" href="/css/adminlte/all.min.css">
  <link rel="stylesheet" href="/css/adminlte/OverlayScrollbars.min.css">
  <link rel="stylesheet" href="/css/adminlte/adminlte.min.css">
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

  <link rel="stylesheet" href="/css/adminlte/style.css">

</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
<div class="wrapper">
