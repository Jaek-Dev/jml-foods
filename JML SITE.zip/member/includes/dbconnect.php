<?php

$con = mysqli_connect("localhost","root","","jml-foods");
// $con = mysqli_connect("localhost","jmlfoods_jimmy","olaife2020","jmlfoods_jml");

// const dbhost = "localhost";   
// const dbuser = "jmlfoods_jimmy";
// const password = "olaife2020";
// const dbname = "jmlfoods_jml";
?>