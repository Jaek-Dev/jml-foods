

  <footer class="main-footer text-center text-sm">
    <strong>Copyright &copy; 2020 <a href="https://jmlfoods.com">JML Foods</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
    </div>
  </footer>

</div>
</div>
</div>
</body>
</html>
