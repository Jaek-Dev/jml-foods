<?php
include ('security.php');

// include ('includes/dbconnect.php');
$page_title = "My Downlines";
include ('includes/header.php');
include ('includes/navbar.php');
require_once( "classes/database.php" );
require_once( "classes/users.php" );
$username = $_SESSION[ "user" ][ "username" ];
$DB = new DB;
$user = new User( $username, "username" );
$id = $user->get( "id" );
$name = $user->get( "name" );
?>

        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">My Downlines</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="index">Home</a></li>
              <li class="breadcrumb-item active">My Downlines</li>
            </ol>
          </div>
        </div>
<hr>
<div class="card">
  <div class="container-fluid">
    <div class="ro">
      <div style="padding: 15px 5px;">
        <?php
          //Check for downlines
          $sql = "SELECT * FROM referrals WHERE ref_id = $id";
          if( $DB->numRows( $sql ) < 1 ) {
            echo "<div class='alert alert-danger'>";
            echo "<h6><i class='fa fa-exclamation-triangle'></i> You currently do not have any downline.</h6>";
            echo "</div>";
          } else { ?>
            <table class="table table-bordered">
              <tr>
                <td colspan="2">
                  
                  <center>
                    <img src="/img/avatar.png" alt="" height="80" width="80" style="border-radius: 50%; margin-bottom: 6px;" />
                    <!-- <i class="fa fa-user fa-lg"></i> -->
                    <br />
                    <?= strtoupper( $name ) ?>
                  </center>
                </td>
              </tr>

              <tr>
                <?php
                $sql = "SELECT * FROM referrals WHERE ref_id = $id";
                $result = $DB->select( $sql );
                foreach( $result as $key => $value ) {
                  //Get the name of the user
                  $refd_id = $value[ "user_id" ];
                  $res = new User( $refd_id );
                  echo "<td width='50%' style='padding: 0;'>";
                  echo "<table class='table' style='margin: -1px;'>";
                  echo "<tr>";
                  echo "<td colspan='2'>";
                  echo "<center>";
                  echo "<img src=\"/img/avatar.png\" alt=\"\" height=\"80\" width=\"80\" style=\"border-radius: 50%; margin-bottom: 6px;\" /><br />";
                  echo strtoupper( $res->get( "name" ) );
                  echo "</center>";
                  echo "</td>";
                  echo "</tr>";

                  //Check if downline has downlines
                  $dsql = "SELECT * FROM referrals WHERE ref_id = $refd_id";
                  if( $DB->numRows( $dsql ) > 1 ) {
                    $dres = $DB->select( $dsql );
                    echo "<tr>";
                    foreach( $dres as $k => $val ) {
                      //Get the user name
                      $refdd_id = $val[ "id" ];
                      $ress = new User( $refdd_id );
                      echo "<td width='50%'>";
                      echo "<center>";
                      echo "<img src=\"/img/avatar.png\" alt=\"\" height=\"80\" width=\"80\" style=\"border-radius: 50%; margin-bottom: 6px;\" /><br />";
                      echo strtoupper( $ress->get( "name" ) );
                      echo "</center>";
                      echo "</td>";
                    }
                    echo "</tr>";
                  }
                  echo "</table></td>";
                }
                
                ?>
              </tr>
            </table>
          <?php }
        ?>
        
      </div>
    </div>
  </div>
</div>
<hr>

<?php
include ('includes/scripts.php');
include ('includes/footer.php');
?>