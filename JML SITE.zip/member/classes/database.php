<?php
/*************************************************************
*    Project Name        JML Food Investment                 *
*    Project URI         https://www.jmlfoods.com            *
*    Project Author      Jay                                 *
*    Author URI          https://m.me/ComputerGuru1          *
*    Author Digit        +234(0)-813-508-7475                *
*    Copyright           GNU V2.2                            *
*    Version             1.0.1                               *
**************************************************************

**************************************************************
*   Database Class 	                                         *
*************************************************************/

/**
 * The class to perform most database operations.
 * Create, Update, Delete
 */
class DB {

	private $conn;
	private const HOSTNAME = "localhost";
	private const USERNAME = "root";
	private const PASSWORD = "";
	private const DATABASE = "jml-foods";

	/**
	 * The class constructor.
	 * Automatically connects to database
	 */
	public function __construct() {
		$this->conn = $this->connect();
	}

	/**
	 * Initializes database connection
	 * @return \mysqli
	 */
	private function connect() {
		$conn = new mysqli( self::HOSTNAME, self::USERNAME, self::PASSWORD, self::DATABASE );

		//Check connection
        if( mysqli_connect_error() ) {
            $conn_err = "Error: [ <b>" . mysqli_connect_errno() . " </b> ]<br>Unable to connect to DataBase.<br><br>";
            $conn_err .= "Error details: <br><b>" . mysqli_connect_error() . "</b><br>";
            die( $conn_err );
        }
        
        //Set database Charset
        $conn->set_charset( "utf8mb4" );
        return $conn;
	}


	/**
	 * Gets information from database
	 * @param string $query
	 * @param string $paramType
	 * @param array $paramArray
	 * @return array|null|void
	 */
	public function select( $query, $paramType = "", $paramArray = array() ) {

		if( $stmt = $this->conn->prepare( $query ) ) {
			if( !empty( $paramType ) && !empty( $paramArray ) ) {
				$this->bindQueryParams( $stmt, $paramType, $paramArray );
			}

			$stmt->execute();
			if( $result = $stmt->get_result() ) {
				if( $result->num_rows > 0 ) {
					while( $row = $result->fetch_assoc() ) {
						$resultset[] = $row;
					}
				}
			}
			
			if( !empty( $resultset ) ) {
				return $resultset;
			}
		}
	}


	/**
	 * Performs a query on the database
	 * @param string $query
	 * @param string $paramType
	 * @param array $paramArray
	 * @return boolean
	 */
	public function query( $query, $paramType = "", $paramArray = array() ) {

		if( $stmt = $this->conn->prepare( $query ) ) {
			if( !empty( $paramType ) && !empty( $paramArray ) ) {
				$this->bindQueryParams( $stmt, $paramType, $paramArray );
			}

			$stmt->execute();
			$stmt->store_result();

			if( !empty( $stmt->affected_rows ) ) {
				return TRUE;
			} else {
				return FALSE;
			}

		}
	}

	/**
	 * Performs an INSERT query on the database
	 * @param string $query
	 * @param string $paramType
	 * @param array $paramArray
	 * @return boolean
	 */
	public function insert( $query, $paramType = "", $paramArray = array() ) {

		if( $stmt = $this->conn->prepare( $query ) ) {

			if( !empty( $paramType ) && !empty( $paramArray ) ) {

				$this->bindQueryParams( $stmt, $paramType, $paramArray );

			}

			$stmt->execute();
			$stmt->store_result();

			if( !empty( $stmt->insert_id ) ) {
				return TRUE;
			} else {
				return FALSE;
			}

		}
	}
    /**
	 * Gets the last mysqli error
	 * @return string
	 */
	public function error() {
		return $this->conn->error;
	}

    /**
	 * Gets the last inserted id from the last insert mysqli query
	 * @return integer
	 */
	public function insert_id() {
		return $this->conn->insert_id;
	}


	/**
	 * Binds query parameters
	 * @param string $stmt
	 * @param string $paramType
	 * @param array $paramArray
	 * @return void
	 */
	public function bindQueryParams( $stmt, $paramType, $paramArray = array() ) {

		$paramValueReference[] = & $paramType;

		for( $i = 0; $i < count( $paramArray ); $i++ ) {

			$paramValueReference[] = & $paramArray[ $i ];
			
		}

		call_user_func_array( array( $stmt, "bind_param" ), $paramValueReference );
	}


	/**
	 * Gets number of rows of a query from database
	 * @param string $query
	 * @param string $paramType
	 * @param array $paramArray
	 * @return integer
	 */
	public function numRows( $query, $paramType = "", $paramArray = array() ) {

		if( $stmt = $this->conn->prepare( $query ) ) {

			if( !empty( $paramType ) && !empty( $paramArray ) ) {
				$this->bindQueryParams( $stmt, $paramType, $paramArray );
			}

			$stmt->execute();
			$stmt->store_result();
			$rows = $stmt->num_rows;

			return $rows;

		}
	}


	/**
	 * Closes the database connection
	 * @param string $query
	 * @param string $paramType
	 * @param array $paramArray
	 * @return array|null|void
	 */
	public function disconnect() {
		$this->conn->close();
	}
}

?>