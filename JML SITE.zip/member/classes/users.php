<?php
/*************************************************************
*    Project Name        JML Food Investment                 *
*    Project URI         https://www.jmlfoods.com            *
*    Project Author      Jay                                 *
*    Author URI          https://m.me/ComputerGuru1          *
*    Author Digit        +234(0)-813-508-7475                *
*    Copyright           GNU V2.2                            *
*    Version             1.0.1                               *
**************************************************************

**************************************************************
*   The Users Class				                             *
*************************************************************/

/**
 * Users Class
 * Performs all the activities regarding to registered users
 */
class User extends DB {

    //Login Info
    private $id;
    private $name;
    private $username;
    private $email;
	private $password;
	private $active;
	private $blocked;
	private $regtime;
    private $lastlogin;
    
    //User Info
    private $sponsor_id;
    private $photo;
	private $phone;
	private $address;
	private $city;
	private $state;
    private $country;
    
    //Account Details
    private $bank_name;
    private $account_name;
    private $account_number;


    /**
     * The constructor! Initializes the user and gets information from the database
     * @param mixed $user
     * @param string $type
     * @return void
     */
    public function __construct( $user, $type = "id" ) {
        parent::__construct();
        $this->initialize( $user, $type );
    }

    /**
     * Gets all the available user information from the database
     * @param mixed $user
     * @param string $type
     * @return object $this
     */
    private function initialize( $user, $type = "id" ) {
        //Check the $type provided
        switch( $type ) {
            case "username":
                //$type is username
                $sql = "SELECT * FROM users WHERE username = ?";
                $rows = parent::numRows( $sql, "s", [ $user ] );
            break;

            case "email":
                //$type is email
                $sql = "SELECT * FROM users WHERE email = ?";
                $rows = parent::numRows( $sql, "s", [ $user ] );
            break;

            default:
                //Default is id
                $sql = "SELECT * FROM users WHERE id = ?";
                $rows = parent::numRows( $sql, "i", [ $user ] );
            break;
        }

        //If user exists
        if( $rows > 0 ) {
            switch( $type ) {
                case "id":
                    //For id
                    $data = parent::select( $sql, "i", [ $user ] );
                break;

                default:
                    //For username or email
                    $data = parent::select( $sql, "s", [ $user ] );
                break;
            }

            //Set the variable values
            $this->id = $data[ 0 ][ "id" ];
            $this->name = $data[ 0 ][ "name" ];
            $this->username = $data[ 0 ][ "username" ];
            $this->email = $data[ 0 ][ "email" ];
            $this->password = $data[ 0 ][ "password" ];
            $this->active = $data[ 0 ][ "active" ];
            $this->blocked = $data[ 0 ][ "blocked" ];
            $this->regtime = $data[ 0 ][ "reg_date" ];
            $this->lastlogin = $data[ 0 ][ "last_login" ];


            //Get the user information
            $sql = "SELECT * FROM user_info WHERE user_id = ?";
            if( parent::numRows( $sql, "i", [ $this->id ] ) > 0 ) {
                $data = parent::select( $sql, "i", [ $this->id ] );
                //Set the variable values
                $this->sponsor_id = $data[ 0 ][ "sponsor_id" ];
                $this->phone = $data[ 0 ][ "phone" ];
                $this->address = $data[ 0 ][ "address" ];
                $this->photo = $data[ 0 ][ "photo" ];
                $this->city = $data[ 0 ][ "city" ];
                $this->state = $data[ 0 ][ "state" ];
                $this->country = $data[ 0 ][ "country" ];
                
            }

            //Get the bank information
            $sql = "SELECT * FROM user_banks WHERE user_id = ?";
            if( parent::numRows( $sql, "i", [ $this->id ] ) > 0 ) {
                $data = parent::select( $sql, "i", [ $this->id ] );
                //Set the variables
                $this->bank_name = $data[ 0 ][ "bank_name" ];
                $this->account_name = $data[ 0 ][ "account_name" ];
                $this->account_number = $data[ 0 ][ "account_number" ];
            }

            return $this;
        } else {
            //User does not exist
            throw new Exception( "User not found!", 1 );
        }
    }

    /**
     * Gets the value of non-accessible varibles
     * @param string $var
     * @return mixed
     */
    public function get( $var ) {
        return $this->{$var};
    }
}
?>