<?php
include ('security.php');

// include ('includes/dbconnect.php');
include ('includes/header.php');
include ('includes/navbar.php');
?>


        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Profile</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="index.php">Home</a></li>
              <li class="breadcrumb-item active">Profile</li>
            </ol>
          </div>
        </div>

<hr>

<div class="card">
     <div class="container">
        <div class="ro">

        <?php
        $username=$_SESSION['user_name'];
        $query = "SELECT * FROM users WHERE username='$username'" ;
        $query_run = mysqli_query($con, $query);
    ?>
            <div class="col-md-12 mt-5 mb-5">
            <form action="code_update.php" method="POST" enctype="multipart/form-data" id="validation" class="form-area"> 
                                        <?php
    if(isset($_SESSION['success']) && $_SESSION['success'] !='')
    {
        echo '<div class="alert alert-info">'.$_SESSION['success'].' <a class="close" data-dismiss="alert">×</a> </div>';
        unset($_SESSION['success']);
    }
    
    if(isset($_SESSION['status']) && $_SESSION['status'] !='')
    {
        echo '<div class="alert alert-danger">'.$_SESSION['status'].' <a class="close" data-dismiss="alert">×</a> </div>';
        unset($_SESSION['status']);
    }
    ?>

            
            
            
            <div class="row">
                    
<?php
    $row=mysqli_fetch_array($query_run);
    {
?>
                                    
                                <div class="col-md-12">
                                    <div class="input-area">
                                        <input name="id" type="text" value="<?php echo $row['id']; ?>" hidden>
                                        <input name="id" type="text" value="<?php echo $row['id']; ?>" disabled>
                                        <label class="floating-label">User ID</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="input-area">
                                        <input name="name" type="tel" value="<?php echo $row['name']; ?>" required="">
                                        <label class="floating-label">Name</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="input-area">
                                        <input name="username" type="text" value="<?php echo $row['username']; ?>" hidden>
                                        <input name="username" type="text" value="<?php echo $row['username']; ?>" disabled>
                                        <label class="floating-label">Username</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="input-area">
                                        <input name="phone" type="tel" value="<?php echo $row['phone']; ?>" required="">
                                        <label class="floating-label">Phone Number</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="input-area">
                                        <input name="email" type="email" value="<?php echo $row['email']; ?>" required="">
                                        <label class="floating-label">Email</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="input-area">
                                        <input name="password" type="password" value="<?php echo $row['password']; ?>">
                                        <label class="floating-label">Password</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="input-area">
                                        <input name="state" type="text" value="<?php echo $row['state']; ?>" required="">
                                        <label class="floating-label">State</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="input-area">
                                        <input name="bank_name" type="text" value="<?php echo $row['bank_name']; ?>">
                                        <label class="floating-label">Bank Name</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="input-area">
                                        <input name="acc_name" type="text" value="<?php echo $row['acc_name']; ?>">
                                        <label class="floating-label">Account Name</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="input-area">
                                        <input name="acc_no" type="number" value="<?php echo $row['acc_no']; ?>">
                                        <label class="floating-label">Account Number</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="input-area">
                                        <input name="sponser_name" type="text" value="<?php echo $row['sponser_name']; ?>" disabled>
                                        <input name="sponser_name" type="text" value="<?php echo $row['sponser_name']; ?>" hidden>
                                        <label class="floating-label">Sponser Name</label>
                                    </div>
                                </div>
                                <div class="col-12 text-center">
                                    <button name="updatebtn" type="submit" class="btn btn btn-primary">Update</button>
                                </div>
                            </div>
                        </form>
            </div>
        </div>
    </div>
</div>

<?php
    }
?>

<hr>

<?php
include ('includes/scripts.php');
include ('includes/footer.php');
?>