<?php
include ('security.php');

// include ('includes/dbconnect.php');
include ('includes/header.php');
include ('includes/navbar.php');
?>

<div class="row mb-2">
    <div class="col-sm-6">
    <h1 class="m-0 text-dark">Password</h1>
    </div>
    <div class="col-sm-6">
    <ol class="breadcrumb float-sm-right">
        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
        <li class="breadcrumb-item">Setting</li>
        <li class="breadcrumb-item active">Password</li>
    </ol>
    </div>
</div>


<div class="card">
     <div class="container">
        <div class="ro">

        <?php
        $username=$_SESSION['user_name'];
        $query = "SELECT * FROM users WHERE username='$username'" ;
        $query_run = mysqli_query($con, $query);
    ?>
            <div class="col-md-6 mt-5 mb-5 ">
              <div class="section-heading text-center">
                            <h2 class="section-title bg">Change Login Password</h2>
                        </div>
            <form action="code_update.php" method="POST" enctype="multipart/form-data" id="validation" class="form-area"> 
            <?php
    if(isset($_SESSION['success']) && $_SESSION['success'] !='')
    {
        echo '<div class="alert alert-info">'.$_SESSION['success'].' <a class="close" data-dismiss="alert">×</a> </div>';
        unset($_SESSION['success']);
    }
    
    if(isset($_SESSION['status']) && $_SESSION['status'] !='')
    {
        echo '<div class="alert alert-danger">'.$_SESSION['status'].' <a class="close" data-dismiss="alert">×</a> </div>';
        unset($_SESSION['status']);
    }
?>     
  
            <div class="row">
                    
<?php
    $row=mysqli_fetch_array($query_run);
    {
?>
          
                                <div class="col-md-12">
                                    <div class="input-area">
                                        <!-- <label class="1floating-label">User ID</label> -->
                                        <input name="id" type="text" value="<?php echo $row['id']; ?>" hidden>
                                        <input name="username" type="text" value="<?php echo $row['username']; ?>" hidden>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="input-area">
                                        <input name="oldpassword" type="text" value="" required="">
                                        <label class="floating-label">Old Password*</label>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="input-area">
                                        <input name="newpassword" type="text" required="">
                                        <label class="floating-label">New Password*</label>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="input-area">
                                        <input name="repassword" type="text" required="">
                                        <label class="floating-label">Re type Password*</label>
                                    </div>
                                </div>
                                <div class="col-12 text-center">
                                    <button name="updatepassword" type="submit" class="btn btn btn-primary">Update</button>
                                </div>
                            </div>
                        </form>
            </div>

          
            </div>
        </div>
    </div>
</div>

<?php
    }

?>




<hr>



<?php
include ('includes/scripts.php');
include ('includes/footer.php');
?>