<?php
include ('security.php');

include ('includes/header.php');
include ('includes/navbar.php');
// include ('includes/dbconnect.php');
?>


<div class="row mb-2">
    <div class="col-sm-6">
    <h1 class="m-0 text-dark">Bank Details</sub></h1>
    </div>
    <div class="col-sm-6">
    <ol class="breadcrumb float-sm-right">
        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
        <li class="breadcrumb-item active">Setting</li>
        <li class="breadcrumb-item active">Bank Details</li>
    </ol>
</div>
</div>

<hr>

<div class="card">
     <div class="container">
        <div class="ro">

        <?php
        $username=$_SESSION['user_name'];
        $query = "SELECT * FROM users WHERE username='$username'" ;
        $query_run = mysqli_query($con, $query);
    ?>
            <div class="col-md-6 mt-5 mb-5 ">
              <div class="section-heading text-center">
                            <h2 class="section-title bg">Bank Account Details</h2>
                        </div>
            <form action="code_update.php" method="POST" enctype="multipart/form-data" id="validation" class="form-area"> 
            <?php
    if(isset($_SESSION['success']) && $_SESSION['success'] !='')
    {
        echo '<div class="alert alert-info">'.$_SESSION['success'].' <a class="close" data-dismiss="alert">×</a> </div>';
        unset($_SESSION['success']);
    }
    
    if(isset($_SESSION['status']) && $_SESSION['status'] !='')
    {
        echo '<div class="alert alert-danger">'.$_SESSION['status'].' <a class="close" data-dismiss="alert">×</a> </div>';
        unset($_SESSION['status']);
    }
?>     
  
            <div class="row">
                    
<?php
    $row=mysqli_fetch_array($query_run);
    {
?>
          
                                <div class="col-md-12">
                                    <div class="input-area">
                                        <!-- <label class="1floating-label">User ID</label> -->
                                        <input name="id" type="text" value="<?php echo $row['id']; ?>" hidden>
                                        <input name="username" type="text" value="<?php echo $row['username']; ?>" hidden>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="input-area">
                                        <input name="bank_name" type="text" value="<?php echo $row['bank_name']; ?>">
                                        <label class="floating-label">Bank Name</label>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="input-area">
                                        <input name="acc_name" type="text" value="<?php echo $row['acc_name']; ?>">
                                        <label class="floating-label">Account Name</label>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="input-area">
                                        <input name="acc_no" type="number" value="<?php echo $row['acc_no']; ?>">
                                        <label class="floating-label">Account Number</label>
                                    </div>
                                </div>
                                <div class="col-12 text-center">
                                    <button name="updatebank" type="submit" class="btn btn btn-primary">Update</button>
                                </div>
                            </div>
                        </form>
            </div>

          
            </div>
        </div>
    </div>
</div>

<?php
    }

?>




<hr>


<?php
include ('includes/scripts.php');
include ('includes/footer.php');
?>