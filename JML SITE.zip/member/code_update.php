<?php
session_start();

include ('includes/dbconnect.php');


if(isset($_POST['updatebtn']))
{
    $id = $_POST['id'];
    $username = $_POST['username'];
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    // $password = $_POST['password'];
    // $cpassword = $_POST['confirmpassword'];
    $state = $_POST['state'];

    $query = "UPDATE users SET name='$name', phone='$phone', email='$email', state='$state' WHERE id='$id' AND username='$username'";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['success'] = "Your Profile is Updated";
        header('location: profile');
        // echo "Profile Added Welcome $name', $id '$phone','$email', '$state'";

    }
    else
    {
        $_SESSION['status'] = "Your Profile is Not Updated";
        header('location: profile');
    }
}
?>



<?php

include ('includes/dbconnect.php');


if(isset($_POST['updatebank']))
{
    $id = $_POST['id'];
    $username = $_POST['username'];
    $bank_name = $_POST['bank_name'];
    $acc_name = $_POST['acc_name'];
    $acc_no = $_POST['acc_no'];

    $query = "UPDATE users SET bank_name='$bank_name', acc_name='$acc_name', acc_no='$acc_no' WHERE id='$id' AND username='$username'";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['success'] = "Bank Details is Updated";
        header('location: bankdetails');
        // echo "Profile Added Welcome $bank_name', $id '$acc_name'";

    }
    else
    {
        $_SESSION['status'] = "Bank Details is Not Updated";
        header('location: bankdetails');
    }
}
?>



<?php

include ('includes/dbconnect.php');


if(isset($_POST['updatepassword']))
{
    $id = $_POST['id'];
    $username = $_POST['username'];
    $oldpassword = $_POST['oldpassword'];
    $newpassword = $_POST['newpassword'];
    $repassword = $_POST['repassword'];

    if ($newpassword === $repassword)
    {
        $query = "SELECT password from users WHERE id='$id' AND username='$username'";
        $query_run = mysqli_query($con, $query);
        
        if(mysqli_num_rows($query_run) > 0)
        {
            while($row = mysqli_fetch_assoc($query_run))
            {
                // echo $row['password'];

                if ($row['password'] === $oldpassword)
                {

                    $pquery = "UPDATE users SET password='$newpassword' WHERE id='$id' AND username='$username'";
                    $pquery_run = mysqli_query($con, $pquery);
                    
                    if($pquery_run)
                    {
                        $_SESSION['success'] = "Password is Updated";
                        header('location: password');
                    }
                    else
                    {
                        $_SESSION['status'] = "Password is Not Updated";
                        header('location: Password');
                    }
                }
                else
                {
                $_SESSION['status'] = "Old Password Not Correct";
                header('location: Password');
                }
            }
        }
        else
        {
            $_SESSION['status'] = " Old Password Not Correct";
            header('location: Password');
        }
    }
    else
    {
        $_SESSION['status'] = "Password Does Not Match";
        header('location: password');
    }
}
?>

<?php
// session_start();

// include ('includes/dbconnect.php');

// if(isset($_POST['delete_btn']))
// {
//     $id = $_POST['delete_id'];

//     $query = "DELETE FROM register WHERE id='$id'";
//     $query_run = mysqli_query($con, $query);

//     if($query_run)
//     {
//         $_SESSION['success'] = "Your Data is Deleted";
//         header('location: register.php');
//     }
//     else
//     {
//         $_SESSION['status'] = "Your Data is Not Deleted";
//         header('location: register.php');
//     }
// }
?>