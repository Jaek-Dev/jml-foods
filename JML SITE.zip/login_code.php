<?php
session_start();
include ('includes/dbconnect.php');

// include ('security.php');

if(isset($_POST['login_btn']))
{
    $username_login = $_POST['username'];
    $password_login = $_POST['password'];

    $query = "SELECT * FROM users WHERE username='$username_login' AND password = '$password_login' ";
    $query_run = mysqli_query($con, $query);

    if(mysqli_fetch_array($query_run))
    {
        $_SESSION['user_name'] = $username_login;
        // echo $_SESSION['user_name'];
        header('location: member/index');
    }
    else
    {
        $_SESSION['status'] = "Username / Password is Invalid";
        header('location: login');
    }
}



?>