-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 26, 2020 at 06:36 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jml-foods`
--

-- --------------------------------------------------------

--
-- Table structure for table `sponser`
--

CREATE TABLE `sponser` (
  `id` int(50) NOT NULL,
  `sponser_name` text NOT NULL,
  `downline_name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sponser`
--

INSERT INTO `sponser` (`id`, `sponser_name`, `downline_name`) VALUES
(1, 'Capable', 'Boobi'),
(2, 'Capable', 'Bohz'),
(3, 'Capable', 'Bohzz'),
(4, 'Capable', 'Bohzzq'),
(5, 'Capable', 'MMM'),
(6, 'Capable', 'MMMttt'),
(7, 'Capable', 'Excel jimmy'),
(8, 'Capable', 'Excel jimm'),
(9, 'Capable', 'abcde');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(50) NOT NULL,
  `name` text NOT NULL,
  `username` text NOT NULL,
  `phone` text NOT NULL,
  `email` text NOT NULL,
  `password` int(50) NOT NULL,
  `state` text NOT NULL,
  `bank_name` text NOT NULL,
  `acc_name` text NOT NULL,
  `acc_no` varchar(10) NOT NULL,
  `sponser_name` text NOT NULL,
  `joined_date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `password`) VALUES
(1, 'Anthony Miche', 'Capable', 'donsomimicheal35@gmail.com', 111),
(5, 'Anthony Micheal', 'Bohzzq', 'ddonsl@gmail.com', 111),
(6, 'Anthony Micheal', 'MMM', 'mwer@gmail.com', 11),
(7, 'Anthony Micheal', 'MMMttt', 'tttr@gmail.com', 11),
(8, 'Anthony Micheal', 'Excel jimmy', 'don5@gmail.com', 111),
(9, 'Anthony Micheal', 'Excel jimmy1212', 'don5@gmail.comqq', 1111),
(10, 'Anthony Micheal', 'Excelrr', 'don5@gmail.co2', 111),
(11, 'Anthony Okagba', 'Excel jimm', '35@gmail.com', 111),
(12, 'Anthony Micheal', 'abcde', 'cheal35@gmail.com', 1234);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `sponser`
--
ALTER TABLE `sponser`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `sponser`
--
ALTER TABLE `sponser`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
