<?php
/*************************************************************
*    Project Name        JML Food Investment                 *
*    Project URI         https://www.jmlfoods.com            *
*    Project Author      Jay                                 *
*    Author URI          https://m.me/ComputerGuru1          *
*    Author Digit        +234(0)-813-508-7475                *
*    Copyright           GNU V2.2                            *
*    Version             1.0.1                               *
**************************************************************

**************************************************************
*   The User Login      	                                 *
*************************************************************/
ob_start();
session_start();
// include ('security.php');
// $_SESSION['username'] = '';
// include ('includes/dbconnect.php');
// include ('includes/header.php');
// include ('includes/navbar.php');
// include ('includes/dbconnect.php');
require_once( "member/classes/database.php" );
require_once( "member/classes/users.php" );
?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Login - JML FOODS INVESTMENT COMPANY</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta data-react-helmet="true" name="description" content="JML FOODS INVESTMENT COMPANY is Africa's most innovative food production saving services with various options to help you quench your hunger.">
        <meta data-react-helmet="true" name="keywords" content="JML, Food, JML Food, food production, INVESTMENT COMPANY, Help you quench your hunger">
        <meta data-react-helmet="true" property="og:title" content="JML FOODS | INVESTMENT COMPANY">
        <meta data-react-helmet="true" property="og:description" content="JML FOODS INVESTMENT COMPANY is Africa's most innovative food production saving services with various options to help you quench your hunger.">
        <meta data-react-helmet="true" property="og:type" content="website">
        <meta data-react-helmet="true" property="og:url" content="https://jmlfoods.com/">
        <meta data-react-helmet="true" property="og:site_name" content="JML FOODS | Investment Company">
        <meta name="author" content="Anthony Okagba">
        <link rel="shortcut icon" href="img/logo.png" type="image/x-icon">

        <link rel="stylesheet" href="/css/bootstrap-grid.min.css">
        <link rel="stylesheet" href="/css/bootstrap-reboot.min.css">
        <link rel="stylesheet" href="/css/bootstrap.min.css">
        <!-- <link rel="stylesheet" href="css/font-awesome.min.css"> -->
        <link rel="stylesheet" href="/css/style.css">
        <link href="http://fonts.googleapis.com/css?family=Raleway:200,400,300,600,500,700" rel="stylesheet" type="text/css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        
    </head>
    <body>
        <div id="loader-wrapper" style="display: none;" class=""> 
            <div class="world"> 
                <img src="img/loader.svg" alt=""> 
            </div>
        </div>

        <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top shadow">
            <a class="navbar-brand" href="/"><img class="logo" src="/img/logo.png" alt="logo" style="width: 70px;"></a>
            <button class="navbar-toggler" data-target="#my-nav" data-toggle="collapse" aria-controls="my-nav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div id="my-nav" class="collapse navbar-collapse">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="/">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#about">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#work">How it Works</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#gallery">Gallery</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#contact"> Contact Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#compensation">Compensation Plan</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="/account/login"> Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/account/register">Register</a>
                    </li>
                </ul>
            </div>
        </nav>

        <div class="img-banner" style="padding-top:70px">
            <div class="img">
                <h1>Login to Account</h1>
            </div>
        </div>

        <div id="contact">
            <div class="" style="padding-top: 100px;">
                <div class="contact parallax_img" style="background-position: 0px 373.36px;">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-8 col-sm-12 m-auto">
                                <div class="contact-form">
                                    <div class="section-heading text-center">
                                        <h2 class="section-title bg">Login to Account</h2>
                                    </div>
                                    <form method="POST" id="validation" class="form-area">
                                        <?php
                                        if( isset( $_POST[ "login" ] ) ) {
                                            $DB = new DB;
                                            //Get the user inputs
                                            $login = trim( $_POST[ "username" ] );
                                            $password = trim( $_POST[ "password" ] );

                                            if( empty( $login ) or empty( $password ) ) {
                                                echo "<div class='alert alert-danger'>";
                                                echo "Please enter your username and password.";
                                                echo "</div>";
                                            } else {
                                                //Check if user exists
                                                $sql = "SELECT * FROM users WHERE username = ? OR email = ?";
                                                if( $DB->numRows( $sql, "ss", [ $login, $login ] ) < 1 ) {
                                                    //Invalid username, error
                                                    if( filter_var( $login, FILTER_VALIDATE_EMAIL ) ) {
                                                        echo "<div class='alert alert-danger'>";
                                                        echo "Invalid email address and/or password.";
                                                        echo "</div>";
                                                    } else {
                                                        echo "<div class='alert alert-danger'>";
                                                        echo "Invalid username and/or password.";
                                                        echo "</div>";
                                                    }
                                                    
                                                } else {
                                                    //Email or username is valid
                                                    //Check for password
                                                    $data = $DB->select( $sql, "ss", [ $login, $login ] );
                                                    $user_id = $data[ 0 ][ "id" ];
                                                    $email = $data[ 0 ][ "email" ];
                                                    $username = $data[ 0 ][ "username" ];
                                                    $passkey = $data[ 0 ][ "password" ];
                                                    $blocked = $data[ 0 ][ "blocked" ];
                                                    if( password_verify( $password, $passkey ) ) {
                                                        //Password verified
                                                        //Check if user is blocked
                                                        if( $blocked == 1 ) {
                                                            echo "<div class='alert alert-danger'>";
                                                            echo "You were blocked for violating our terms and conditions. If you think this was a mistake, please <a href='/#contact'>contact us now</a>.";
                                                            echo "</div>";
                                                        } else {
                                                            //All tests passed... Start the user session
                                                            //And redirect to user panel
                                                            $_SESSION[ "user" ] = [];
                                                            $_SESSION[ "user" ][ "id" ] = $user_id;
                                                            $_SESSION[ "user" ][ "username" ] = $username;
                                                            $_SESSION[ "user" ][ "email" ] = $email;
                                                            header( "Location: /account/dashboard" );
                                                            exit();
                                                        }

                                                    } else {
                                                        if( filter_var( $login, FILTER_VALIDATE_EMAIL ) ) {
                                                            echo "<div class='alert alert-danger'>";
                                                            echo "Invalid email address and/or password.";
                                                            echo "</div>";
                                                        } else {
                                                            echo "<div class='alert alert-danger'>";
                                                            echo "Invalid username and/or password.";
                                                            echo "</div>";
                                                        }
                                                    }


                                                    /*$sql = "SELECT * FROM users WHERE username = ? AND password = ? OR email = ? AND password = ?";
                                                    if( $DB->numRows( $sql, "ssss", [ $login, $password, $login, $password ] ) < 1 ) {
                                                        //Incorrect password
                                                        
                                                    } else {
                                                        echo "Correct username and password<BR>";
                                                        echo password_hash( $password, PASSWORD_DEFAULT );
                                                    }*/
                                                }
                                            }
                                        }
                                        ?>
<?php
    // if(isset($_SESSION['success']) && $_SESSION['success'] !='')
    // {
    //     echo '<div class="alert alert-info">'.$_SESSION['success'].' <a class="close" data-dismiss="alert">×</a> </div>';
    //     unset($_SESSION['success']);
    // }
    
    // if(isset($_SESSION['status']) && $_SESSION['status'] !='')
    // {
    //     echo '<div class="alert alert-danger">'.$_SESSION['status'].' <a class="close" data-dismiss="alert">×</a> </div>';
    //     unset($_SESSION['status']);
    // }
?>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="input-area">
                                                    <input name="username" type="text" required="required">
                                                    <label class="floating-label">Username*</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="input-area">
                                                    <input name="password" type="password" required="">
                                                    <label class="floating-label">Password*</label>
                                                </div>
                                            </div>
                                            <div class="col-12 text-center">
                                                <button name="login" type="submit" class="btn btn-danger" value="true">Login</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        

        <?php
include ('includes/scripts.php');
include ('includes/footer.php');
?>