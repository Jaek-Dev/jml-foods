<?php
session_start();
date_default_timezone_set("Africa/Lagos"); 
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>JML Foods Investment Company</title>
        <meta name="google-site-verfication" content="google-site-verfication=jJEXqyFahQaFJpD6RjkUUIjRe8ZNz1bGLBWJR38YoMQ">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta data-react-helmet="true" name="description" content="JML Foods Investment Company is Africa's most innovative food production saving services with various options to help you quench your hunger.">
        <meta data-react-helmet="true" name="keywords" content="JML, Food, JML Food, food production, INVESTMENT COMPANY, Help you quench your hunger">
        <meta data-react-helmet="true" property="og:title" content="JML FOODS | INVESTMENT COMPANY">
        <meta data-react-helmet="true" property="og:description" content="JML FOODS Investment Company is Africa's most innovative food production saving services with various options to help you quench your hunger.">
        <meta data-react-helmet="true" property="og:type" content="website">
        <meta data-react-helmet="true" property="og:url" content="https://jmlfoods.com/">
        <meta data-react-helmet="true" property="og:site_name" content="JML Foods | Investment Company">
        <!-- <meta data-react-helmet="true" property="og:site_logo" content="https://jmlfoods.com/img/logo.png"> -->
        <meta name="author" content="Anthony Okagba">
        <link rel="shortcut icon" href="img/logo.png" type="image/x-icon">

        <link rel="shortcut icon" href="https://jmlfoods.com/img/logo.png" type="image/x-icon" />
        <link rel="apple-touch-icon" href="https://jmlfoods.com/img/logo.png" />
        <link rel="apple-touch-icon" sizes="57x57" href="https://jmlfoods.com/img/logo.png" />
        <link rel="apple-touch-icon" sizes="72x72" href="https://jmlfoods.com/img/logo.png" />
        <link rel="apple-touch-icon" sizes="76x76" href="https://jmlfoods.com/img/logo.png" />
        <link rel="apple-touch-icon" sizes="114x114" href="https://jmlfoods.com/img/logo.png" />
        <link rel="apple-touch-icon" sizes="120x120" href="https://jmlfoods.com/img/logo.png" />
        <link rel="apple-touch-icon" sizes="144x144" href="https://jmlfoods.com/img/logo.png" />
        <link rel="apple-touch-icon" sizes="152x152" href="https://jmlfoods.com/img/logo.png" />
        <link rel="icon" type="icon" href="https://jmlfoods.com/img/logo.png"/>

        <link rel="stylesheet" href="css/bootstrap-grid.min.css">
        <link rel="stylesheet" href="css/bootstrap-reboot.min.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/css/fontawesome.min.css">
        <link rel="stylesheet" href="css/css/all.min.css">
        <!-- <link rel="stylesheet" href="css/css/solid.min.css"> -->
        <!-- <link rel="stylesheet" href="css/webfonts/fa-brands-400.svg">
        <link rel="stylesheet" href="css/webfonts/fa-regular-400.svg"> -->
        <!-- <link rel="stylesheet" href="css/webfonts/fa-solid-900.svg"> -->
        <link rel="stylesheet" href="css/style.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> -->
        <link href="http://fonts.googleapis.com/css?family=Poppins:200,400,300,600,500,700" rel="stylesheet" type="text/css">
        <script src="https://kit.fontawesome.com/CapableBohz.js" crossorigin="anonymous"></script>

    </head>
    <body data-spy="scroll" data-target="#navbar" data-offset="50">
        <nav id="navbar" class="navbar navbar-expand-lg navbar-light bg-danger fixed-top shadow nav">
            <a class="navbar-brand" href="index.php"><img class="logo" src="img/logo.png" alt="logo" style="width: 50px;"></a>
            <button class="navbar-toggler" data-target="#my-nav" data-toggle="collapse" aria-controls="my-nav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div id="my-nav" class="collapse navbar-collapse">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item  activee">
                        <a class="nav-link" href="/">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#about">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#work">How it Works</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#gallery">Gallery</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#contact"> Contact Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#compensation">Compensation Plan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/account/login"> Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/account/register">Register</a>
                    </li>
                </ul>
            </div>
        </nav>

        <div id="home">
            <div style="padding-top:60px">
                <div id="demo" class="carousel slide" data-ride="carousel">

                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img src="img/nav1.jpg" width="100%" height="">
                            <div class="carousel-caption">
                                <h1>Another example headlineaaaaaaaaaa.</h1>
                                <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget
                                    metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
                                <p><a class="btn btn-lg btn-primary" href="#" role="button">Learn more</a></p>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <img src="img/burger.jpeg" width="100%" height="">
                            <div class="carousel-caption">
                                <h1>Another example headline.</h1>
                                <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget
                                    metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
                                <p><a class="btn btn-lg btn-primary" href="#" role="button">Learn more</a></p>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <img src="img/001.jpg" width="100%" height="">
                            <div class="carousel-caption">
                                <h1>Another example headline.</h1>
                                <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget
                                    metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
                                <p><a class="btn btn-lg btn-primary" href="#" role="button">Learn more</a></p>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <img src="img/001.jpg" width="100%" height="600">
                            <div class="carousel-caption">
                                <h1>Another example headline.</h1>
                                <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget
                                    metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
                                <p><a class="btn btn-lg btn-primary" href="#" role="button">Learn more</a></p>
                            </div>
                        </div> 
                        <div class="carousel-item">
                            <img src="img/001.jpg" width="100%" height="600">
                            <div class="carousel-caption">
                                <h1>Another example headline.</h1>
                                <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget
                                    metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
                                <p><a class="btn btn-lg btn-primary" href="#" role="button">Learn more</a></p>
                            </div>
                        </div> 
                    </div>
                    
                </div>
            </div>
        </div>
        <div id="about" class="" style="padding-top: 10px;">
            <div class="container">
                <div class="pt-5">
                    <h3 class="pb-3 font-big center welcome">Welcome to JML Foods Investment Company Nigeria</h3>
                </div>
                <div class="row">
                    <div class="col-md-6 font-sm text-justify pop">
                        <img src="">
                        <p>JML Foods Investment Company is Africa's most innovative food production 
                            saving services with various options to help you quench your hunger. 
                            We have created a strategy that could help our partners to make extra 
                            income on monthly and weekly bases. And to also make you acquire your 
                            long dream asset at the click of a button.
    
                            <br>We are Using technology as our primary leverage, we are gradually 
                            becoming the largest online cum offline food and wealth provider for 
                            the people.
                        </p>
                    </div>
                    <div class="col-md-6 font-sm text-justify">
                        <p>
                            <br>Since inception, we have been able to use our local food production 
                            such as Poundo Yam, Semovita, and Wheat to improve the economic standing 
                            of all our customers at every level providing powerful opportunities and 
                            insight. As a confirmation that the right chord had been struck, the 
                            concept is quickly attracting huge number of participants from all 
                            walks of life-civil servants, traders, artisans, pensioners, farmers, 
                            students and other low income earners-whose fortunes have now taken an 
                            upward swing.
                            
                            <br>We believe good nutrition and food security should not be an 
                            exclusive preserve of a few. It should be readily available and 
                            accessible to everyone; irrespective of creed, status, income or 
                            geographical spread.
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <div class="about-u" style="padding-top: 100px;" id="work">
            <div class="how-work">
                <div class="container">
                    <div class="heading">
                        <h3 class="center">How it Works</h3>
                    </div>
                    <div class="row center">
                        <div class="col-lg-4 col-md-4 ">
                            <div class="how-it-works">
                                <div class="how-img">
                                    <img src="img/002.png">
                                </div>
                                <h3>Create an Account</h3>
                                <p>Simply register via wallet or scratch card with $31.</p>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 ">
                            <div class="how-it-works">
                                <div class="how-img">
                                    <img src="img/003.png">
                                </div>
                                <h3 style="margin-top: 20px;">Refer Family &amp; Friends </h3>
                                <p>Build your downlines by inviting members to register with your username.</p>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 ">
                            <div class="how-it-works">
                                <div class="how-img">
                                    <img src="img/004.png">
                                </div>
                                <h3>Start Earning</h3>
                                <p>Earn foodstuffs and get bonus as you move through the stages.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="bg-danger pb-5">
            <div class="font-big">
                <h3 class="center font-big">What People Say</h3>
            </div>
            <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
                <div class="container center">
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img src="img/img1.png" alt="">
                            <div class="caption client-say">
                                <h4>Peter Mike</h4>
                                <p>"JML Foods have restored the believe of the people once again"</p>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <img src="img/img2.png">
                            <div class="caption client-say">
                                <h4>Adekole Ayo</h4>
                                <p>"I registered with faith based on my previous experience and now i want 
                                    to register more because its indeed a great pleasure to be here"</p>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <img src="img/img3.png" alt="">
                            <div class="caption client-say">
                                <h4>Hassan Moh</h4>                                
                                <p>"A Company everyone should be in partner with, lots of food."</p>
                            </div>
                        </div>
                    </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>

        <div id="gallery" class="bg-inf" style="padding-top:5rem; padding-bottom:10rem;">
            <div class="font-big pb-5">
                <h3 class="center font-big">Gallery</h3>
            </div>

            <div class="img-box containerq col-md-12 col-sm-12">
                <div class=" row col-md-4">
                    <img src="img/IMG-20200621-WA0085.jpg" alt="" styleq="width: 450px;">
                </div>
                <div class="row col-md-4">
                    <img src="img/IMG-20200621-WA0080.jpg" alt="" styleq="width: 450px;">
                </div>
                <div class=" row col-md-4">
                    <img src="img/IMG-20200621-WA0082.jpg" alt="" styleq="width: 450px;">
                </div>
                <div class=" row col-md-4">
                    <img src="img/IMG-20200621-WA0083.jpg" alt="" styleq="width: 450px;">
                </div>
                <div class=" row col-md-4">
                    <img src="img/IMG-20200621-WA0084.jpg" alt="" styleq="width: 450px;">
                </div>
                <div class=" row col-md-4">
                    <img src="img/IMG-20200621-WA0085.jpg" alt="" styleq="width: 450px;">
                </div>
            </div>
        </div>

        <div id="contact">
            <div class="" style="padding-top:100px">
                <div id="quote" class="single-section silver-bg quote-area"> 
                    <div class="container"> 
                        <div class="row"> 
                            <div class="col-lg-6 col-sm-12 m-auto"> 
                                <div class="section-heading "> 
                                    <h2 class="section-title">Contact Us </h2> 
                                    <p>Don’t Hesitate to Contact with us for any kind of information </p> 
                                </div> 
                            </div> 
                        </div>
                    </div>
                </div>
            </div>        
            <div class="" style="padding-top: 100px;">
                <div class="contact parallax_img" style="background-position: 0px 373.36px;">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-8 col-sm-12 m-auto">
                                <div class="contact-form">
                                    <div class="section-heading text-center">
                                        <h2 class="section-title">Send us your message</h2>
                                        <p class="section-description">We are very Quick to Reply</p>
                                    </div>
                                    <form action="" method="POST" enctype="multipart/form-data" id="validation" class="form-area">
<!-- <?php
    if(isset($_SESSION['success']) && $_SESSION['success'] !='')
    {
        echo '<div class="alert alert-info">'.$_SESSION['success'].' <a class="close" data-dismiss="alert">×</a> </div>';
        unset($_SESSION['success']);
    }
    
    if(isset($_SESSION['status']) && $_SESSION['status'] !='')
    {
        echo '<div class="alert alert-danger">'.$_SESSION['status'].' <a class="close" data-dismiss="alert">×</a> </div>';
        unset($_SESSION['status']);
    }
?> -->

                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="select-area">
                                                    <select name="message_title">
                                                        <option selected disabled>Message Title</option>
                                                        <option value="Registration">Registration</option>
                                                        <option value="Enquiry">Enquiry</option>
                                                        <option value="Others">Others</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="input-area">
                                                    <input name="name" type="text" required="required">
                                                    <label class="floating-label">Name*</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="input-area">
                                                    <input name="phone" type="tel" required="">
                                                    <label class="floating-label">Phone*</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="input-area">
                                                    <input name="email" type="email" required="">
                                                    <label class="floating-label">Email*</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="input-area">
                                                    <input name="state" type="text" required="">
                                                    <label class="floating-label">State*</label>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="text-area">
                                                    <textarea name="message" rows="1" required=""></textarea>
                                                    <label class="floating-label">Message</label>
                                                </div>
                                            </div>
                                            <div class="col-12 text-center">
                                                <button name="message_btn" type="submit" class="btn btn btn-danger">Send Message</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>




<?php


if(isset($_POST['message_btn']))
{

    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $state = $_POST['state'];
    $message_title = $_POST['message_title'];
    $message = $_POST['message'];
    
    $to = 'donsomimicheal35@gmail.com' AND 'contactjmlfoods01@gmail.com';
    $subject = '(JML Foods Message:) '.$message_title.'';
    $message = " \r\n
    Contact Details: \r\n
    Name: ".$name."\r\n
    Phone Number: ".$phone."\r\n
    Email: ".$email."\r\n
    State: ".$state."  \r\n
    Message: ".$message." \r\n";
    // Brought By: JML Foods Investment Company Inc \r\n;
    // ".date("F j, Y, g:i a")." - JML Foods \r\n;
    // JML Foods LTD \r\n";
    $header = "From: <".$email."> \r\n";
    "Reply-To: ".$email." \r\n"; 

    if(mail($to,$subject,$message,$header)){
        
        echo "
        <script>
              alert('Message Sent');
              window.location='index.php#contact';
         </script>";
    }
    else 
    {
        echo "
        <script>
              alert('Message Not Sent');
              window.location='index.php#contact';
         </script>
         ";
    }
}
?>

    

<?php
include ('includes/scripts.php');
include ('includes/footer.php');
?>