<?php
/*************************************************************
*    Project Name        JML Food Investment                 *
*    Project URI         https://www.jmlfoods.com            *
*    Project Author      Jay                                 *
*    Author URI          https://m.me/ComputerGuru1          *
*    Author Digit        +234(0)-813-508-7475                *
*    Copyright           GNU V2.2                            *
*    Version             1.0.1                               *
**************************************************************

**************************************************************
*   The Head					                             *
*************************************************************/
?>

<!DOCTYPE html>
<html lang="en-US" dir="ltr">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, user-scalable=no">
        <meta name="author" content="Jay & Anthony" />
        <meta name="keywords" content="<?= KEYWORDS; ?>" />
        <meta name="description" content="<?= SITE_DESC; ?>" />
        <meta name="theme-color" content="#cc0000" />
    </head>
</html>