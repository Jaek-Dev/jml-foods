<?php
/*************************************************************
*    Project Name        JML Food Investment                 *
*    Project URI         https://www.jmlfoods.com            *
*    Project Author      Jay & Anthony                       *
*    Author URI          https://m.me/ComputerGuru1          *
*    Author Digit        +234(0)-813-508-7475                *
*    Copyright           GNU V2.2                            *
*    Version             1.0.1                               *
**************************************************************

**************************************************************
*   The Initializer	    		                             *
*************************************************************/
//Start user session
session_start();

//Include the necessary files
require_once( "settings.php" );
require_once( "defs.php" );

?>