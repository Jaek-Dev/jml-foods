<?php
/*************************************************************
*    Project Name        Online Fashion Store                *
*    Project URI         https://www.jaekonisclothing.com    *
*    Project Author      SirJay                              *
*    Author URI          https://m.me/ComputerGuru1          *
*    Author Digit        +234(0)-813-508-7475                *
*    Copyright           GNU V2.2                            *
*    Version             1.0.1                               *
**************************************************************

**************************************************************
*   Definitions				                                 *
*************************************************************/

// DO NOT EDIT anything here...
// This file is for the whole
// website use. If you edit it,
// your site will malfunction
// and it will be unavailable.

// Import the settings
require_once( "settings.php" );

// Database Definition
define( "DB_NAME", $db_name );
define( "DB_USER", $db_user );
define( "DB_SERVER", $db_host );
define( "DB_PASS", $db_pass );

// Website Definition
define( "SITE_NAME", $site_name );
define( "SITE_URI", $site_url );
define( "SITE_EMAIL", $site_email );
define( "SITE_DESC", $desc );
define( "TEXT_LOGO", $text_logo );
define( "KEYWORDS", $keywords );
define( "ROOT", $_SERVER[ "DOCUMENT_ROOT" ] );

// Social Media Definition 
define( "FACEBOOK", $fb_page );
define( "TWITTER", $tw_page );
define( "INSTAGRAM", $in_page );
define( "WHATSAPP", $wa_num );
?>