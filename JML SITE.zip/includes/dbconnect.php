<?php

$con = mysqli_connect("localhost","root","","jml-foods");

// const dbhost = "localhost";   
// const dbuser = "jmlfoods_jimmy";
// const password = "olaife2020";
// const dbname = "jmlfoods_jml";
?>