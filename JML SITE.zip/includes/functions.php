<?php
/*************************************************************
*    Project Name        JML Food Investment                 *
*    Project URI         https://www.jmlfoods.com            *
*    Project Author      Jay                                 *
*    Author URI          https://m.me/ComputerGuru1          *
*    Author Digit        +234(0)-813-508-7475                *
*    Copyright           GNU V2.2                            *
*    Version             1.0.1                               *
**************************************************************

**************************************************************
*   The Head					                             *
*************************************************************/

/**
 * This function checks whether a user or an admin is logged in
 * @param string $person
 * @return boolean
 */
function isLoggedIn( $person = "user" ) {
    $person = strtolower( $person );
    if( empty( $_SESSION ) ) {
        return false;
    } else {
        switch( $person ) {
            case "admin":
                if( !empty( $_SESSION[ "admin" ] ) ) {
                    return true;
                } else {
                    return false;
                }
            break;

            default:
                if( !empty( $_SESSION[ "user" ] ) ) {
                    return true;
                } else {
                    return false;
                }
            break;
        }
    }
}

/**
 * Redirects a user to a the provided URL
 * @param string $url
 * @return void
 */
function go( $url ) {
    header( "Location: $url" );
    exit();
}
?>