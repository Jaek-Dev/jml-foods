<div class="foote" id="register.php">
            <footer class="enddigital">
                <div class="foot">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-4 col-md-6">
                                <div class="our-info">
                                    <h3 class="hg">Contact Us</h3>
                                    <div class="font-sm contact-colo">
                                        <p class="foot_icon">
                                            <i class="fas fa-map-marker" aria-hidden="true"> </i>
                                            Shop 31, 282 Adeguyi complex opp larfarge cement ijegun road Lagos.
                                            <br><a href="tel:+2348023396375"><i class="fa fa-mobile"> +2348023396375</i></a> &nbsp;<br> 
                                            <!-- <br><a href="tel:+2348023396375"><i class="fa fa-mobile">+2348023396375</i></a> &nbsp;<br>  -->
                                            <a href="mailto:contactjmlfoods01@gmail.com"><i class="fa fa-envelope"> contactjmlfoods01@gmail.com</i></a>
                                            <!-- <i class="fa fa-phone nav-item" aria-hidden="true"></i> -->
                                        </p>

                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6">
                                <div class="openhour">
                                    <h3 class="hg">Opening Hours</h3>
                                    <table class=" contact-colo">
                                        <tbody>
                                            <tr>
                                                <th>Monday: </th>
                                                <td>8:00 AM – 7:00 PM</td>
                                            </tr>
                                            <tr>
                                                <th>Tuesday: </th>
                                                <td>8:00 AM – 7:00 PM</td>
                                            </tr>
                                            <tr>
                                                <th>Wednesday: </th>
                                                <td>8:00 AM – 7:00 PM</td>
                                            </tr>
                                            <tr>
                                                <th>Thursday: </th>
                                                <td>8:00 AM – 7:00 PM</td>
                                            </tr>
                                            <tr>
                                                <th>Friday: </th>
                                                <td>8:00 AM – 7:00 PM</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6">
                                <div class="our-info">
                                    <h3 class="hg">Contact Us</h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- <hr> -->
                <div class="footer">
                    <div class="copyright">
                        <h5>
                      <div class="col-sm-12 pt-2 pb-2">
                        <div class="social-linksk">
                          <a href="https://facebook.com/JMLfoods" title="facebook" target="_blank"><i class="fab fa-facebook"> </i></a>
                          <a href="https://twitter.com/JMLfoods" title="twitter" target="_blank"><i class="fab fa-twitter"> </i></a>
                          <!-- <a href="https://linkedin.com/in/JMLfoods" title="linkedin" target="_blank"><i class="fa fa-linkedin"> </i></a> -->
                          <a href="https://instagram.com/JMLfoods" title="instagram" target="_blank"><i class="fab fa-instagram"> </i></a>
                        </div>
                      </div>

                        Copyright &copy; 2020 JML FOODS INVESTMENT COMPANY Nigeria Ltd. | All Rights Reserved.</h5>
                    </div>
                </div>
            </footer>
        </div>

        <style>
            #myBtn {
                /* display: none;
                position: fixed;
                bottom: 20px;
                right: 30px;
                z-index: 99;
                font-size: 18px;
                border: none;
                outline: none;
                background-color: rgb(0, 0, 0, 0.3);
                color: white;
                cursor: pointer;
                border-radius: 4px; */
                width: 40px;
                height: 40px;
                text-indent: -9999px;
                opacity: 0.3;
                position: fixed;
                bottom: 20px;
                right: 40px;
                display: none;
                background-image: url(img/icon_top.png);
            }
            
            #myBtn:hover {
                /* background-color: #555; */
                opacity: 0.8;
            }
        </style>    
        
        <!-- <a href="#" onclick="topFunction()" id="myBtn" title="Go to top"><i class="fas fa-arrow-up"></i></a> -->
        <a href="#" class="scrollup" onclick="topFunction()" id="myBtn" title="Go to top"></a>
        </body>

        <script>
            // Get the button
            var mybutton = document.getElementById("myBtn");
            
            // When the user scrolls down 20px from the top of the document, show the button
            window.onscroll = function() {scrollFunction()};
            
            function scrollFunction() {
                if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                mybutton.style.display = "block";
                } else {
                mybutton.style.display = "none";
                }
            }

            // When the user clicks on the button, scroll to the top of the document
            function topFunction() {
                document.body.scrollTop = 0;
                document.documentElement.scrollTop = 0;
            }
        </script>

</html>