<?php
/*************************************************************
*    Project Name        JML Food Investment                 *
*    Project URI         https://www.jmlfoods.com            *
*    Project Author      Jay & Anthony                       *
*    Author URI          https://m.me/ComputerGuru1          *
*    Author Digit        +234(0)-813-508-7475                *
*    Copyright           GNU V2.2                            *
*    Version             1.0.1                               *
**************************************************************

**************************************************************
*   The Settings				                             *
*************************************************************/

// Only change the text in quotes
// else, your website may not be
// available again.

//Database Settings
$db_name = "jml";          
$db_user = "root";                   
$db_host = "localhost";              
$db_pass = "";

// Website Settings
$site_name = "JML Foods Investment";
$text_logo = "JML Foods";
$site_email = "info@jmlfoods.com";
//$protocol = $_SERVER[ "REQUEST_SCHEME" ];
$protocol = ( !empty( $_SERVER[ "HTTPS" ] ) and $_SERVER[ "HTTPS" ] !== "off" or $_SERVER[ "SERVER_PORT" ] == 443 ) ? "https://" : "http://";
$site_url = $protocol . $_SERVER[ "HTTP_HOST" ]; 
$desc = "JML FOODS Investment Company is Africa's most innovative food production saving services with various options to help you quench your hunger.";
$keywords = "JML, Food, JML Food, food production, Investment Company, Food Investment, Quench hunger, Help you quench your hunger";

// Social Media Settings 
$fb_page = "JMLFoods";          //Your page @username on facebook    
$tw_page = "JMLFoods"; //Your page @username on twitter
$in_page = "JMLFoods"; //Your page @username on instagram
$wa_num = "2348135087475";      //Your whatsapp number

?>